# Studio

Next.js 14 + TypeScript + Tailwind + Supabase + Resend.

## Run locally
1. `npm install`
2. `cp .env.example .env.local` and fill in the values
3. Supabase: create a project, open SQL Editor, run `supabase/schema.sql`. Copy URL, anon key, service role key into `.env.local`.
4. Resend: create an API key, verify your domain, set `EMAIL_FROM` and `BUSINESS_EMAIL`.
5. `npm run dev` then open http://localhost:3000

## Test the inquiry form
Submit the form at `#contact`. Check the `inquiries` table in Supabase, your business inbox, and the client confirmation. Use `onboarding@resend.dev` as `EMAIL_FROM` for testing before domain verification (it only delivers to your own Resend account email).

## Deploy to Vercel
Push to GitHub, import the repo at vercel.com, add every variable from `.env.example` under Settings > Environment Variables, then deploy.

## Custom domain
Vercel project > Settings > Domains > add your domain, then set the A / CNAME records Vercel shows at your registrar. Verify the same domain in Resend (add its DNS records) so emails send from it.
