create extension if not exists "pgcrypto";
create table profiles (id uuid primary key references auth.users on delete cascade, full_name text, role text not null default 'client' check (role in ('client','admin')), created_at timestamptz default now());
create table inquiries (id uuid primary key default gen_random_uuid(), full_name text not null, email text not null, business_name text, service text not null, budget text not null, deadline date, description text not null, reference_url text, status text not null default 'new' check (status in ('new','accepted','rejected')), created_at timestamptz default now());
create table projects (id uuid primary key default gen_random_uuid(), client_id uuid references profiles(id) on delete set null, title text not null, status text not null default 'planning' check (status in ('planning','active','review','completed')), created_at timestamptz default now());
create or replace function is_admin() returns boolean language sql security definer stable as $$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
create or replace function handle_new_user() returns trigger language plpgsql security definer as $$ begin insert into profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
alter table profiles enable row level security; alter table inquiries enable row level security; alter table projects enable row level security;
create policy "own profile" on profiles for select using (id = auth.uid() or is_admin());
create policy "update own profile (not role)" on profiles for update using (id = auth.uid()) with check (id = auth.uid() and role = (select role from profiles where id = auth.uid()));
create policy "admin all inquiries" on inquiries for all using (is_admin()) with check (is_admin()); -- public inserts go through the server API only
create policy "client sees own projects" on projects for select using (client_id = auth.uid() or is_admin());
create policy "admin manages projects" on projects for all using (is_admin()) with check (is_admin());
-- After registering your own account, make yourself admin:
-- update profiles set role = 'admin' where id = (select id from auth.users where email = 'you@yourdomain.com');
