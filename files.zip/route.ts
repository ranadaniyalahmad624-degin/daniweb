import { NextResponse } from "next/server";
import { inquirySchema } from "@/lib/validation";
import { supabaseAdmin } from "@/lib/supabase";
import { sendInquiryEmails } from "@/lib/email";
export const runtime = "nodejs";
const hits = new Map<string, number[]>(); // simple per-IP limiter; swap for Upstash Redis at scale
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "unknown";
  const now = Date.now(); const recent = (hits.get(ip) ?? []).filter(t => now - t < 600_000);
  if (recent.length >= 3) return NextResponse.json({ error: "Too many requests. Please try again in a few minutes." }, { status: 429 });
  hits.set(ip, [...recent, now]);
  let json: unknown; try { json = await req.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const parsed = inquirySchema.safeParse(json);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Please check your details." }, { status: 422 });
  const { hp, ...data } = parsed.data;
  const { error } = await supabaseAdmin().from("inquiries").insert({ ...data, deadline: data.deadline || null, reference_url: data.reference_url || null });
  if (error) { console.error(error); return NextResponse.json({ error: "We couldn't save your inquiry. Please try again." }, { status: 500 }); }
  sendInquiryEmails(parsed.data).catch(console.error); // inquiry is saved even if email fails
  return NextResponse.json({ ok: true });
}
