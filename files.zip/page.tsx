import { Globe, ShoppingCart, LayoutTemplate, RefreshCw, Search, Wrench, Building2, MessageCircle } from "lucide-react";
import InquiryForm from "@/components/InquiryForm";
const services = [
  [Globe,"Website Development","Fast, custom-coded sites built to rank and convert."],
  [Building2,"Business Website Design","A credible online home for your company."],
  [ShoppingCart,"E-commerce Development","Stores that make buying effortless."],
  [LayoutTemplate,"Landing Page Design","Single pages built around one goal: leads."],
  [RefreshCw,"Website Redesign","Modernise a site that no longer represents you."],
  [Search,"SEO Optimization","Be found by people already looking for you."],
  [Wrench,"Website Maintenance","Updates, backups and security, handled."],
] as const;
export default function Home() {
  const wa = process.env.NEXT_PUBLIC_WHATSAPP;
  return (<>
    <header className="fixed inset-x-0 top-0 z-20 border-b border-line/60 bg-ink/70 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="#" className="font-display text-xl font-semibold">Studio</a>
        <div className="hidden gap-8 text-sm text-mist sm:flex"><a href="#services" className="hover:text-white">Services</a><a href="#why" className="hover:text-white">Why us</a><a href="#contact" className="hover:text-white">Contact</a></div>
        <a href="#contact" className="rounded-full bg-white px-5 py-2 text-sm font-medium text-ink">Start a Project</a>
      </nav>
    </header>
    <main>
      <section className="glow relative px-6 pb-28 pt-40">
        <div className="mx-auto max-w-6xl">
          <h1 className="rise font-display text-5xl font-semibold leading-[1.02] tracking-tight sm:text-7xl lg:text-8xl">We Build Digital Experiences That Grow Your Business.</h1>
          <p className="rise rise-2 mt-8 max-w-xl text-lg text-mist">Websites, online stores and search visibility for businesses that want to look established and win more customers.</p>
          <div className="rise rise-3 mt-10 flex flex-wrap gap-4">
            <a href="#contact" className="rounded-full bg-iris px-8 py-4 font-medium transition hover:bg-sky">Start a Project</a>
            <a href="#services" className="rounded-full border border-line px-8 py-4 font-medium transition hover:border-iris">View Our Work</a>
          </div>
        </div>
      </section>
      <section id="services" className="mx-auto max-w-6xl px-6 py-24">
        <h2 className="font-display text-4xl font-semibold">What we do</h2>
        <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {services.map(([Icon, t, d]) => (<a href="#contact" key={t} className="group bg-navy p-8 transition hover:bg-[#121B40]"><Icon className="text-iris transition group-hover:text-sky" size={26}/><h3 className="mt-6 font-display text-xl">{t}</h3><p className="mt-2 text-mist">{d}</p></a>))}
        </div>
      </section>
      <section id="why" className="mx-auto max-w-6xl px-6 py-24">
        <h2 className="font-display text-4xl font-semibold">Why work with us</h2>
        <div className="mt-10 grid gap-10 sm:grid-cols-3 text-mist">
          <p><strong className="block text-white">One person accountable</strong>You talk to the developer building your site, not an account manager.</p>
          <p><strong className="block text-white">Clear milestones</strong>Track progress, files and invoices in your client portal.</p>
          <p><strong className="block text-white">Built to be found</strong>Semantic markup, fast loads and SEO from day one.</p>
        </div>
      </section>
      <section id="contact" className="mx-auto max-w-3xl px-6 py-24">
        <h2 className="font-display text-4xl font-semibold">Tell us about your project</h2>
        <p className="mb-8 mt-3 text-mist">We reply within one business day.</p>
        <InquiryForm/>
        {wa && <a href={`https://wa.me/${wa}`} className="mt-6 inline-flex items-center gap-2 text-mist hover:text-white"><MessageCircle size={18}/>Prefer WhatsApp? Message us</a>}
      </section>
    </main>
    <footer className="border-t border-line px-6 py-10 text-center text-sm text-mist">© {new Date().getFullYear()} Studio. All rights reserved.</footer>
  </>);
}
